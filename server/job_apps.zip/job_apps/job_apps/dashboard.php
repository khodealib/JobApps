﻿<?php include('includes/header.php');?>
    

<?php include('includes/menu.php');?>
<?php 

//total category						
$sql="SELECT COUNT(*) as num FROM tbl_category";
$total_category= mysql_fetch_array(mysql_query($sql));
$total_category = $total_category['num'];

//total sub category
$sql="SELECT COUNT(*) as num FROM tbl_job";
$total_job= mysql_fetch_array(mysql_query($sql));
$total_job= $total_job['num'];


					
					?>	

    <div class="content">
        
        <div class="header">
             

            <h1 class="page-title">داشبورد</h1>
        </div>
        
        <ul class="breadcrumb">
            <li><a href="dashboard">خانه</a> <span class="divider">/</span></li>
            <li class="active">داشبورد</li>
        </ul>

        <div class="container-fluid">
            <div class="row-fluid">
                    

<div class="row-fluid">
 
    <div class="block">
        <a href="#page-stats" class="block-heading" data-toggle="collapse">آخرین آمار</a>
        <div id="page-stats" class="block-body collapse in">

                        <div class="stat-widget-container">
                        <div class="stat-widget">
                        <div class="stat-button">
                        <p class="title"><?php echo $total_category;?></p>
                        <dt><p  class="detail">لیست دسته بندی</p></dt>
                </div>
                        
                </div>
                        <div class="stat-widget">
                        <div class="stat-button">
                        <p class="title"><?php echo $total_job;?></p>
                        <dt><p class="detail">لیست کار ها</p></dt>
                        </div>
                        
                </div>
                        
                
                </div>
                        
                </div>
                       
            
        </div>
    </div>
</div>

                 
           
  <?php include('includes/footer.php');?>     