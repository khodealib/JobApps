﻿<?php include('includes/header.php');?>
    
<?php include('includes/menu.php');?>

<?php include('includes/function.php');
	  include('language/language.php'); 
 	  require_once("thumbnail_images.class.php");
	  
	 
if(isset($_POST['submit']) and isset($_GET['add']))
	{
			 $job_image=rand(0,99999)."_".$_FILES['job_image']['name'];
			$pic1=$_FILES['job_image']['tmp_name'];
		
		 $tpath1='images/'.$job_image;
			
				 copy($pic1,$tpath1);
				 
			$thumbpath='images/thumb/'.$job_image;
						$obj_img = new thumbnail_images();
						$obj_img->PathImgOld = $tpath1;
						$obj_img->PathImgNew =$thumbpath;
						$obj_img->NewWidth = 100;
						$obj_img->NewHeight = 100;
						if (!$obj_img->create_thumbnail_images()) 
						  {
							echo $_SESSION['msg']="Thumbnail not created...please upload image again";
						    exit;
						  }
	 
			$data = array(
			'category_id'  =>  $_POST['category_id'],
			'job_name'  =>  $_POST['job_name'],
			'job_designation'  =>  $_POST['job_designation'],
			'job_desc'  =>  addslashes($_POST['job_desc']),
			'job_salary'  =>  $_POST['job_salary'],
			'job_company_name'  =>  $_POST['job_company_name'],
			'job_company_website'  =>  $_POST['job_company_website'],
			'phone_number'  =>  $_POST['phone_number'],
			'job_mail'  =>  $_POST['job_mail'],
			'job_vacancy'  =>  $_POST['job_vacancy'],
			'job_address'  =>  $_POST['job_address'],
			'job_qualification'  =>  $_POST['job_qualification'],			
			'job_skill'  =>  $_POST['job_skill'],
			'job_image'  =>  $job_image,
			'job_map_latitude'=> $_POST['job_map_latitude'],
			'job_map_longitude'=> $_POST['job_map_longitude']
			
		     );
            $qry = Insert('tbl_job',$data);
        
		    $_SESSION['msg']="13";
			header("location:manage_job");	 
			exit;
		
	}
	
	if(isset($_GET['id']))
	{
			 
            $project_qry="SELECT * FROM tbl_job where id='".$_GET['id']."'";
			$project_result=mysql_query($project_qry);
			$project_row=mysql_fetch_assoc($project_result);
	}
	        
	
	if(isset($_POST['submit']) and isset($_POST['id']))
	{
		if($_FILES['job_image']['name']!=""){
		
				$img_res=mysql_query('SELECT * FROM tbl_job where id=\''.$_POST['id'].'\'');
				$img_row=mysql_fetch_assoc($img_res);
				
				if($img_row['job_image']!="")
				{
					unlink('images/thumb/'.$img_row['job_image']);
					unlink('images/'.$img_row['job_image']); 
				}
			
		
				$job_image=rand(0,99999)."_".$_FILES['job_image']['name'];
				$pic1=$_FILES['job_image']['tmp_name'];
			
				$tpath1='images/'.$job_image;
				
				 copy($pic1,$tpath1);
				 
					$thumbpath='images/thumb/'.$job_image;
						$obj_img = new thumbnail_images();
						$obj_img->PathImgOld = $tpath1;
						$obj_img->PathImgNew =$thumbpath;
						$obj_img->NewWidth = 100;
						$obj_img->NewHeight = 100;
						if (!$obj_img->create_thumbnail_images()) 
						  {
							echo $_SESSION['msg']="Thumbnail not created... please upload image again";
						    exit;
						  }	 		 
	 
			$data = array(
		    'category_id'  =>  $_POST['category_id'],
			'job_name'  =>  $_POST['job_name'],
			'job_designation'  =>  $_POST['job_designation'],
			'job_desc'  =>  addslashes($_POST['job_desc']),
			'job_salary'  =>  $_POST['job_salary'],
			'job_company_name'  =>  $_POST['job_company_name'],
			'job_company_website'  =>  $_POST['job_company_website'],
			'phone_number'  =>  $_POST['phone_number'],
			'job_mail'  =>  $_POST['job_mail'],
			'job_vacancy'  =>  $_POST['job_vacancy'],
			'job_address'  =>  $_POST['job_address'],
			'job_qualification'  =>  $_POST['job_qualification'],			
			'job_skill'  =>  $_POST['job_skill'],
			'job_image'  =>  $job_image,
			'job_map_latitude'=> $_POST['job_map_latitude'],
			'job_map_longitude'=> $_POST['job_map_longitude']
			);
			$project_edit=Update('tbl_job', $data, "WHERE id = '".$_POST['id']."'");	
			}
			else
			{
									
			$data = array(
			'category_id'  =>  $_POST['category_id'],
			'job_name'  =>  $_POST['job_name'],
			'job_designation'  =>  $_POST['job_designation'],
			'job_desc'  =>  addslashes($_POST['job_desc']),
			'job_salary'  =>  $_POST['job_salary'],
			'job_company_name'  =>  $_POST['job_company_name'],
			'job_company_website'  =>  $_POST['job_company_website'],
			'phone_number'  =>  $_POST['phone_number'],
			'job_mail'  =>  $_POST['job_mail'],
			'job_vacancy'  =>  $_POST['job_vacancy'],
			'job_address'  =>  $_POST['job_address'],
			'job_qualification'  =>  $_POST['job_qualification'],			
			'job_skill'  =>  $_POST['job_skill'],
			'job_map_latitude'=> $_POST['job_map_latitude'],
			'job_map_longitude'=> $_POST['job_map_longitude']	
			
			);
		    $project_edit=Update('tbl_job', $data, "WHERE id = '".$_POST['id']."'");

            }
		      if ($project_edit > 0){
					
			$_SESSION['msg']="14";
			header("Location:add_job?id=".$_POST['id']);
			exit;
			} 	
		
	 
			}
			$cat_qry="select * from tbl_category";
			$cat_result=mysql_query($cat_qry);
			

?>
<script src="js/jquery.min.js"></script>

<script type="text/javascript" src="js/jquery.validate.min.js"></script>

<script type="text/javascript">
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#addeditnews").validate({
                rules: {
                    
										category_id: "required",
										job_name: "required",
										job_designation: "required",
										job_desc: "required",
										job_salary: "required",
										job_company_name: "required",
										job_company_website: "required",
										phone_number: "required",
										job_mail: "required",
										job_vacancy: "required",
										job_address: "required",
										job_qualification: "required",										
										job_skill: "required",
										
										
										<?php if(!isset($_GET['id'])){?>
										job_image: "required"
								        <?php }  ?>
										
										
								
                   
               },
                messages: { 
                                        category_id: "Please Add category name",
										job_name: "Please enter Job name name",
										job_designation: "Please enter Job Designation name",
									    job_desc: "Please enter Job Desc name",
										job_salary: "Please enter Job Salary name",
										job_company_name: "Please enter Company Name name",
										job_company_website: "Please enter Company Website name",
										phone_number: "Please enter Phone number name",
										job_mail: "Please enter Job Mail name",
										job_vacancy: "Please enter Job Vacancy name",
										job_address: "Please enter Job City name",
										job_qualification: "Please enter Job Country name",										
									    job_skill: "Please enter Job Skill name",
									
										
										<?php if(!isset($_GET['id'])){?>
										job_image: "Please enter job image",
										<?php }?>
										  
             },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
</script>
<script src="js/add_category.js"></script>
<style>

#addeditnews label.error {
    color: #FB3A3A;
    display: inline-block;
    margin: 4px 0 5px 20px;
    padding: 0;
    text-align: left;
    width: 220px;
}
</style>

<div class="content">
        
        <div class="header">
            
            <h1 class="page-title"><?php if(isset($_GET['id'])){?>ویرایش کار<?php }else {?>افزودن کار<?php }?></h1>
        </div>
        
            <ul class="breadcrumb">
            <li><a href="dashboard">خانه</a> <span class="divider">/</span></li>
            <li class="active"><?php if(isset($_GET['id'])){?>ویرایش کار<?php }else {?>افزودن کار<?php }?></li>
       	 </ul>

        <div class="container-fluid">
            <div class="row-fluid">
                    
 
<div class="well">
<p style="color:#990000; font-size:14px;" align="center">
					<?php if(isset($_SESSION['msg'])){ 
						?>
							
					<div class="alert alert-info">
       					 <button type="button" class="close" data-dismiss="alert">×</button>
        				 <?php echo $admin_lang[$_SESSION['msg']] ; ?>
   					 </div>
                            
                            <?php unset($_SESSION['msg']);		
							
					}?>
</p>
     
    <div id="myTabContent" class="tab-content">
    
    <div class="tab-pane active in" id="home">
    <form action="" name="addeditnews" id="addeditnews" method="post" class="jNice" enctype="multipart/form-data"
     onsubmit="<?php if(isset($_GET['id'])){?>return editValidation(this)<?php } else { ?> return checkValidation(this)
     <?php } ?>">
					 
<input type="hidden" name="id" value="<?php echo $_GET['id'];?>" />	
        
<label>نام دسته بندی</label>
<select name="category_id" id="category_id">

<option value="">انتخاب دسته بندی</option>

<?php
       
        while($cat_row=mysql_fetch_array($cat_result))
	    {
?> 
<option value="<?php echo $cat_row['cid'];?>" <?php if($cat_row['cid']==$project_row['category_id']){?>selected<?php }?>><?php echo $cat_row['category_name'];?></option>
<?php 
}
?>    
</select> 
<label>نام کارe</label>
<input type="text" name="job_name" id="job_name" value="<?php echo $project_row['job_name'];?>"/>

<label>تعیین شغل</label>
<input type="text" name="job_designation" id="job_designation" value="<?php echo $project_row['job_designation'];?>"/>
     
  
<label>تعیین شغل:</label>
<textarea input type="text" name="job_desc" id="job_desc"  value=""><?php echo $project_row['job_desc'];?></textarea>

<script>                             
          CKEDITOR.replace( 'job_desc' );
</script>

<label>حقوق شغلی</label>
<input type="text" name="job_salary" id="job_salary" value="<?php echo $project_row['job_salary'];?>"/>
  
<label>نام شرکت شغلی</label>
<input type="text" name="job_company_name" id="job_company_name" value="<?php echo $project_row['job_company_name'];?>"/>
  
<label>وب سایت شرکت شغلی</label>
<input type="text" name="job_company_website" id="job_company_website" value="<?php echo $project_row['job_company_website'];?>"/>

<label>شماره تلفن شغلی</label>
<input type="text" name="phone_number" id="phone_number" value="<?php echo $project_row['phone_number'];?>"/>
  
<label>نامه شغلی</label>
<input type="text" name="job_mail" id="job_mail" value="<?php echo $project_row['job_mail'];?>"/>
  
<label>فرصت شغلی</label>
<textarea input type="text" name="job_vacancy" id="job_vacancy" value=""><?php echo $project_row['job_vacancy'];?></textarea>

<label>آدرس شغل</label>
<textarea type="text" name="job_address" id="job_address" cols="40" rows="5" value=""><?php echo $project_row['job_address'];?></textarea>
  
<label>صلاحیت شغلی</label>
<textarea type="text" name="job_qualification" id="job_qualification" cols="30" rows="4" value=""><?php echo $project_row['job_qualification'];?></textarea>

<label>مهارت شغلی</label>
<textarea type="text" name="job_skill" id="job_skill" value=""><?php echo $project_row['job_skill'];?></textarea>


<label>تصویر شغل</label>
<?php if(isset($_GET['id'])){?>
<img src="images/thumb/<?php echo $project_row['job_image'];?>">
<?php }?>        	
<input type="file" name="job_image" id="job_image" value="<?php echo $project_row['job_image'];?>" class="input-xlarge" >

<label>&nbsp;</label>
         
  <script src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>

	<!-- CSS and JS for our code -->
	<link rel="stylesheet" type="text/css" href="css/jquery-gmaps-latlon-picker.css"/>
	<script src="js/jquery-gmaps-latlon-picker.js"></script>
         
         <fieldset class="gllpLatlonPicker">
		<input type="text" class="gllpSearchField input-xlarge">
		<input type="button" class="gllpSearchButton btn btn-primary" value="Search" style="margin-top: -10px;">
    &nbsp;&nbsp;
    	Zoom: <input type="text" class="gllpZoom input-xlarge" value="3"/>
		<input type="button" class="gllpUpdateButton btn btn-primary" value="Update Map" style="margin-top: -10px;">
    
		<br/><br/>
    <p>نشانگر را جابجا کنید ، یا روی نقشه دو بار کلیک کنید.</p>
		<div class="gllpMap">Google Maps</div>
		<br/>
		 
        <label>عرض جغرافیایی</label>
        <input type="text" name="job_map_latitude" id="job_map_latitude" value="<?php if(isset($_GET['id'])){echo $project_row['job_map_latitude'];}?>" placeholder="18.524220910029783" class="gllpLatitude input-xlarge" readonly>
        
        <label>عرض جغرافیایی</label>
        <input type="text" name="job_map_longitude" id="job_map_longitude" value="<?php if(isset($_GET['id'])){echo $project_row['job_map_longitude'];}?>" placeholder="73.85761860000002" class="gllpLongitude input-xlarge" readonly>
		</fieldset>
        <br/>
                 
<button class="btn btn-primary" type="submit" name="submit"><?php if(isset($_GET['id'])){?>ویرایش کار
<?php }else {?>افزودن کار<?php }?></button>


             
            
        </div>
        </form>
      </div>
       
  </div>

</div>
     </div>
      
   

<?php include('includes/footer.php');?>                  