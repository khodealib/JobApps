﻿<?php include('includes/header.php');?>
    

<?php include('includes/menu.php');?>

<?php 
    include('includes/function.php');
	include('language/language.php');  
	if(isset($_POST['job_search']))
	 {
	
	 $project_qry="SELECT * FROM tbl_job WHERE tbl_job.job_name like '%".addslashes($_POST['job_name'])."%' ORDER BY tbl_job.id DESC"; 
     $project_result=mysql_query($project_qry);
		 
	 }
	 else
	 {
	 
							$tableName="tbl_job";		
							$targetpage = "manage_job"; 	
							$limit = 15; 
							
							$query = "SELECT COUNT(*) as num FROM $tableName";
							$total_pages = mysql_fetch_array(mysql_query($query));
							$total_pages = $total_pages['num'];
							
							$stages = 3;
							$page=0;
							if(isset($_GET['page'])){
							$page = mysql_escape_string($_GET['page']);
							}
							if($page){
								$start = ($page - 1) * $limit; 
							}else{
								$start = 0;	
								}	
							
							
					        $project_qry="SELECT * FROM tbl_job j,tbl_category c WHERE j.category_id=c.cid
						    ORDER BY j.id  LIMIT $start, $limit"; 
							 
							$project_result=mysql_query($project_qry);
							
	        }
	        if(isset($_GET['id']))
	        {

			$img_project=mysql_query('SELECT * FROM tbl_job WHERE id=\''.$_GET['id'].'\'');
			$img_project_row=mysql_fetch_assoc($img_project);
			
			if($img_project_row['job_image']!="")
		    {
					unlink('images/thumb/'.$img_project_row['job_image']);
					unlink('images/'.$img_project_row['job_image']);
					 
			}
					 
			Delete('tbl_category','id='.$_GET['id'].'');	
			
			$img_res=mysql_query('SELECT * FROM tbl_category WHERE id=\''.$_GET['id'].'\'');
			$img_row=mysql_fetch_assoc($img_res);
				
			if($img_row['job_image']!="")
			{
					unlink('images/thumb/'.$img_row['job_image']);
					unlink('images/'.$img_row['job_image']);
					 
			}	 
			 
			Delete('tbl_job','id='.$_GET['id'].'');
			
			 $_SESSION['msg']="15";
			 header( "Location:manage_job");
			 exit;
	        }
	      if(isset($_GET['status_deactive']))
	        {
		
		    $data = array(
			'job_status'  =>  '0',
			);
		
		 $project_edit=Update('tbl_job', $data, "WHERE id = '".$_GET['status_deactive']."'");
		
		 $_SESSION['msg']="11";
		 header( "Location:manage_job");
		 exit;
         }
		 
		 if(isset($_GET['status_active']))
	    {
		
		$data = array(
			'job_status'  =>  '1',
			);
		
		$project_edit=Update('tbl_job', $data, "WHERE id = '".$_GET['status_active']."'");
		
		$_SESSION['msg']="12";
		 header( "Location:manage_job");
		 exit;
	}
	      
?>
<div class="content">
        
        <div class="header">
            
            <h1 class="page-title">لیست کار ها</h1>
        </div>
        
            <ul class="breadcrumb">
            <li><a href="dashboard">خانه</a> <span class="divider">/</span></li>
            <li class="active">لیست کار ها</li>
       	 </ul>

         <div class="container-fluid">
            <div class="row-fluid">
                    
<div class="btn-toolbar">
    <button class="btn btn-primary" onclick="window.location.href='add_job?add'"><i class="icon-plus"></i>افزودن کار</button>
     
  <div class="btn-group">
   <div class="search-well">
                      <form class="form-inline" action="" method="post">
                          <input class="input-xlarge" placeholder="Search Job..." name="job_name" id="appendedInputButton" type="text" required>
                          <button class="btn" type="submit" name="job_search"><i class="icon-search"></i> برو</button>
                      </form>
            				</div>
  </div>
</div>
<div class="well">

<p style="color:#990000; font-size:14px;" align="center">
					<?php if(isset($_SESSION['msg'])){ 
						?>
							
					<div class="alert alert-info">
       					 <button type="button" class="close" data-dismiss="alert">×</button>
        				 <?php echo $admin_lang[$_SESSION['msg']] ; ?>
   					 </div>
                            
                            <?php unset($_SESSION['msg']);		
							
					}?>
                    
</p>

    <table class="table">
      <thead>
        <tr>
          <th>#</th>
          
          <th>نام دسته بندی</th>
          <th>نام کار</th>
          <th>تصویر کار</th>
         
        
          <th style="width: 26px;"></th>
        </tr>
      </thead>
      <tbody>
        <?php 
					$i=1;
					while($project_row=mysql_fetch_array($project_result))
					{
				?>
        
            <tr>
              <td><?php echo $i;?></td>
              
              <td><?php echo $project_row['category_name'];?></td>
              
              <td><?php echo $project_row['job_name'];?></td>
              
               <td><img src="images/thumb/<?php echo $project_row['job_image'];?>" /></td> 
            <td>
              <?php if($project_row['job_status']=='1'){?>
             
              <a href="manage_job?status_deactive=<?php echo $project_row['id'];?>"><i class="icon-plus"></i></a>
			 
              <?php }else{ ?>
              
              <a href="manage_job?status_active=<?php echo $project_row['id'];?>"><i class="icon-minus"></i></a>
             
              <?php  }?>
             
              
              <a href="add_job?id=<?php echo $project_row['id'];?>"><i class="icon-pencil"></i></a>
              <a href="manage_job?id=<?php echo $project_row['id'];?>" onclick="return confirm('Are you sure you want to delete this Job ?');" ><i class="icon-remove"></i></a>
          </td>
        </tr>
       <?php $i++;}?>   
      </tbody>
    </table>
  		 
</div>
<?php
								// Initial page num setup
	if ($page == 0){$page = 1;}
	$prev = $page - 1;	
	$next = $page + 1;							
	$lastpage = ceil($total_pages/$limit);		
	$LastPagem1 = $lastpage - 1;					
	
	
	$paginate = '';
	if($lastpage > 1)
	{	
	 
	
		$paginate .= "<div class='pagination'><ul>";
		// Previous
		if ($page > 1){
			$paginate.= "<li><a href='$targetpage?page=$prev'>Prev</a></li>";
		}else{
			$paginate.= "<li><a href='#'>Prev</a></li>";	}
			

		
		// Pages	
		if ($lastpage < 7 + ($stages * 2))	// Not enough pages to breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page){
					$paginate.= "<li><a href='$targetpage?page=$counter'>$counter</a></li>";
				}else{
					$paginate.= "<li><a href='$targetpage?page=$counter'>$counter</a></li>";}					
			}
		}
		elseif($lastpage > 5 + ($stages * 2))	// Enough pages to hide a few?
		{
			// Beginning only hide later pages
			if($page < 1 + ($stages * 2))		
			{
				for ($counter = 1; $counter < 4 + ($stages * 2); $counter++)
				{
					if ($counter == $page){
						$paginate.= "<li><a href='$targetpage?page=$counter'>$counter</a></li>";
					}else{
						$paginate.= "<li><a href='$targetpage?page=$counter'>$counter</a></li>";}					
				}
				$paginate.= "<li><a href='#'>...</a></li>";
				$paginate.= "<li><a href='$targetpage?page=$LastPagem1'>$LastPagem1</a></li>";
				$paginate.= "<li><a href='$targetpage?page=$lastpage'>$lastpage</a></li>";		
			}
			// Middle hide some front and some back
			elseif($lastpage - ($stages * 2) > $page && $page > ($stages * 2))
			{
				$paginate.= "<li><a href='$targetpage?page=1'>1</a></li>";
				$paginate.= "<li><a href='$targetpage?page=2'>2</a></li>";
				$paginate.= "<li><a href='#'>...</a></li>";
				for ($counter = $page - $stages; $counter <= $page + $stages; $counter++)
				{
					if ($counter == $page){
						$paginate.= "<li><a href='$targetpage?page=$counter'>$counter</a></li>";
					}else{
						$paginate.= "<li><a href='$targetpage?page=$counter'>$counter</a></li>";}					
				}
				$paginate.= "<li><a href='#'>...</a></li>";
				$paginate.= "<li><a href='$targetpage?page=$LastPagem1'>$LastPagem1</a></li>";
				$paginate.= "<li><a href='$targetpage?page=$lastpage'>$lastpage</a></li>";		
			}
			// End only hide early pages
			else
			{
				$paginate.= "<li><a href='$targetpage?page=1'>1</a></li>";
				$paginate.= "<li><a href='$targetpage?page=2'>2</a></li>";
				$paginate.= "<li><a href='#'>...</a></li>";
				for ($counter = $lastpage - (2 + ($stages * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page){
						$paginate.= "<li><a href='$targetpage?page=$counter'>$counter</a></li>";
					}else{
						$paginate.= "<li><a href='$targetpage?page=$counter'>$counter</a></li>";}					
				}
			}
		}
					
				// Next
		if ($page < $counter - 1){ 
			$paginate.= "<li><a href='$targetpage?page=$next'>next</a></li>";
		}else{
			$paginate.= "<li><a href='#'>next</a></li>";
			}
			
		$paginate.= "</ul></div>";		
	
	
}
  
 // pagination
 echo $paginate;
								?>	


<?php include('includes/footer.php');?>                  