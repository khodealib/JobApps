﻿<table class="text" cellspacing=0 cellpadding=0 border=0 width="100%">
<tbody>
<tr><td height=20></td></tr>
<tr>
    <td style="border-top:1px solid #d6d6d6;PADDING-TOP:5PX;">        
         <span style="COLOR: #bb5500">Developed </span>by <a href='http://www.viaviweb.com'>کد نویسان جوان</a>
        <?php if($license_agreement_page != ""){ ?>
            <a href="<?php echo $license_agreement_page;?>" target=_blank>خرید فقط برای یک نفر</a>
        <?php } ?>
    </td>
</tr>
<tr><td height=7></td></tr>
</tbody>
</table>

