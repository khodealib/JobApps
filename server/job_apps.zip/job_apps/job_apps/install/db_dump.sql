--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', 'ee1a42a9305cd4d5a3a5cedd7d5e9572', 'tparmar1311@.gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `category_image` varchar(255) NOT NULL,
  `category_status` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cid`, `category_name`, `category_image`, `category_status`) VALUES
(19, 'Technology', '54193_technology.png', '0'),
(20, 'Finance', '72848_finance.png', '0'),
(21, 'Developer', '16619_developer.png', '0'),
(22, 'Bank', '17224_bank.png', '0'),
(23, 'Education  ', '40042_education.png', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_job`
--

CREATE TABLE IF NOT EXISTS `tbl_job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(255) NOT NULL,
  `job_name` varchar(255) NOT NULL,
  `job_designation` varchar(255) NOT NULL,
  `job_desc` varchar(255) NOT NULL,
  `job_salary` varchar(255) NOT NULL,
  `job_company_name` varchar(255) NOT NULL,
  `job_company_website` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `job_mail` varchar(255) NOT NULL,
  `job_vacancy` varchar(255) NOT NULL,
  `job_address` varchar(255) NOT NULL,
  `job_qualification` varchar(255) NOT NULL,
  `job_skill` varchar(255) NOT NULL,
  `job_image` varchar(255) NOT NULL,
  `job_map_latitude` varchar(255) NOT NULL,
  `job_map_longitude` varchar(255) NOT NULL,
  `job_status` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_job`
--

INSERT INTO `tbl_job` (`id`, `category_id`, `job_name`, `job_designation`, `job_desc`, `job_salary`, `job_company_name`, `job_company_website`, `phone_number`, `job_mail`, `job_vacancy`, `job_address`, `job_qualification`, `job_skill`, `job_image`, `job_map_latitude`, `job_map_longitude`, `job_status`) VALUES
(1, '14', 'Php Devloper', 'What is a Job Title (Designation)?', '<ul>\r\n	<li>As the name suggests, it is the title for a job which the employee is assigned in your company</li>\r\n	<li>In sumHR too, it means the same - a Job Title given/assigned to an employee profile</li>\r\n	<li>Though most companies universally refer to&', '10,000', 'Viaviwebtech', 'viaviweb@gmail.com', '9879678542', 'tparmar1311@gmail.com', 'Ahmedabad is the largest city and former capital of the Indian state of Gujarat. Ahmedabad was known as the "Manchester of the East", for its textile industry.The city is the largest', 'Rajkot', 'India', 'Job Skill', '66809_images (2).jpg', '18.5204303', '73.85674369999992', '1'),
(2, '13', 'Asp.net Devloper', ' Job Title (Designation)?', '<p>Commitment to both their job and their employer is something Dennis Boone, former president and CEO of Verizon New Jersey and the current director of Montclair State University&#39;s Feliciano Center for Entrepreneurship at the School of Business, has&', '12,500', 'Ambuja Cement', 'ambujacement@gmail.com', '78515245223', 'ambujacement@gmail.com', 'Jobs in Rajkot, Gujarat: 812 vacancies', 'Baroda', 'India', 'List of Skills for Resumes', '63613_images (11).jpg', '20.8009246', '70.69603059999997', '0'),
(3, '12', 'Java Devloper', 'Job Title (Designation)?', '<p>The third-party products that this article discusses are manufactured by companies that are independent of Microsoft. Microsoft makes no warranty, implied or otherwise, regarding the performance or reliability of these products.</p>\r\n', '15,000', 'Ford', 'fordcompany@gmail.com', '9879678542', 'fordcompany@gmail.com', 'Job Vacancy', 'Amdavadad', 'India', 'List of Skills ', '97549_images (5).jpg', '22.3038945', '70.80215989999999', '1'),
(4, '17', 'Civil Engineering', 'Electrical engineer job description', '<p>To become a civil engineer you normally need a three-year Bachelor of Engineering degree (BEng) or four-year Masters degree (MEng) in civil engineering. These qualifications are important if you want to gain incorporated or chartered engineer status la', '45,000', 'G,H,C,L-Sutrapada', 'ghclsurapada@gmail', '1234567890', 'mayur1311@gmail.com', 'Senior Civil Engineer in PUNE, Maharashtra\r\nINDUSCORP INFRACON LTD.', 'Pune', 'India', 'Civil engineers pune skill', '28860_download.jpg', '23.2248196', '72.64637689999995', '0'),
(5, '18', 'Computer Operator', 'Job Designation', '<p>Each of these tables has two fields called &#39;content&#39; and &#39;title&#39;. I want to be able to use &#39;Like&#39; in my sql statement to look at &#39;messages.content&#39;, &#39;messages.title&#39;, &#39;topics.content&#39;, &#39;topics.title&a', '8,500', 'Rolex', 'rolexcompany@gmail.com', '8521479630', 'maheshparmar@gmail.com', 'Job Vacancy', 'rajkot,nayani chok,\r\nrajkot', 'India', 'computer oparetar skill', '37750_images (1).jpg', '23.022505', '72.57136209999999', '1'),
(7, '19', 'Information Security', 'Senior', '<p>Serves as a Technical Specialist and Information Technology (IT) Security Functional Manager for one or more major elements of the Johnson Space Center (JSC) IT Security Program. Leads or assists in the planning, development, operation, and management ', '$78,355.00 to $101,859.00 / Per Year', 'Lyndon B. Johnson Space Center', 'www.lyndon.uk', '281-483-1260', 'cynthia.d.meza@nasa.gov', '2', 'NASA''s Resume Operations Center\r\nMailstop HS50\r\nMarshall Space Flight Center, AL\r\n35812\r\nUS', 'Position requires one year of specialized experience at the GS-11 level. Specialized experience is experience that has equipped the applicant with the particular competencies/knowledge, skills, and abilities to successfully perform the duties of the posit', 'U.S. citizenship is required\r\nPosition subject to a pre-employment drug test\r\nPosition subject to pre-employment background investigation\r\nSelectee must complete a financial disclosure statement\r\nSuccessful completion of a Secret security investigation wi', '57400_information.jpg', '29.7601927', '-95.36938959999998', '0'),
(8, '21', ' Android Developer', 'Senior Developer', '<p>o you want to write software enjoyed by millions of people? Do you want to help make the world safer? Do you want to want work on a fun team of great engineers?&nbsp;<br />\r\nJoin Norton and Symantec Mobile Security Engineering Team. We are hiring Andro', '$78,355.00 to $101,859.00 / Per Year', 'IBM Infoway', 'ww.ibminfo.com', '919898385708', 'ibminfo@gmail.com', '3', 'IND - Maharashtra, Pune', 'â€¢ Ability to quickly and efficiently write high quality Android software. \r\nâ€¢ Minimum of 6 years experience in software development with success in roles with substantial responsibility and accountability. Experience delivering high quality software i', 'â€¢ Quickly and efficiently develop great, high quality software for Android. \r\nâ€¢ Exercise good architectural judgment in developing software. \r\nâ€¢ Deliver valuable increments of software every sprint in an Agile software development lifecycle. \r\nâ€¢ F', '67767_android.jpeg', '18.5204303', '73.85674369999992', '0'),
(9, '21', 'PHP Developer', 'Senior Developer', '<p>The Web Developer (PHP Developer) will be focused on creating web applications, websites and solutions for robust reporting and tracking of NCrypted&#39;s key business and site/service drivers. This position requires the ability to analyze the project,', '$78,355.00 to $101,859.00 / Per Year', 'VIAVIWEBTECH', 'ww.viaviweb.com', '919898385708', 'viavi@yahoo.com', '5', '3rd floor, Shyam Complex, Parivar Park, Near Mayani Chowk, Rajkot,India - 360005', 'The candidate should be an MCA, BE/BTech (IT/Computers only), MSc (IT) or PGDCA (with BCA) or any equivalent graduation/post-graduation.', 'Should have Working knowledge of PHP, MySQL (LAMP), JavaScript, AJAX, jQuery, jSON, cURL, XML etc. Exposure to SVN, MVC, class/object oriented programming, Smarty Templates an added advantage Sound knowledge of Open Source Applications such as WordPress, ', '2438_phpimage.png', '22.3038945', '70.80215989999999', '0'),
(10, '20', 'Finance Officer', 'Senior', '<p>Infinium Toyota aims to play a major role in establishing Toyota brand and its standard in and around Gujarat.</p>\r\n', 'INR 120,000 - 150,000 ', 'Infinium Toyota', 'www.toyota.com', '281-483-1260', 'ibminfo@gmail.com', '3', 'Toranto,Canada', 'Graduation & above\r\nAge: 20 - 28 Years\r\nPreferably worked in Auto Industry/Automobile Dealership/Finance Industry\r\nPreferably worked in Finance\r\nGood to know English/Gujarati/Hindi', 'Effective communication & presentation skill\r\nKnowledge on Finance scheme\r\nProblem solving and decision making\r\nConfident\r\nInfluencing skill', '14865_finace.jpg', '56.130366', '-106.34677099999999', '0'),
(11, '20', 'Account Manager', 'Senior ', '<p>Assisting in designing and establishing various analytical tools and reports and act as a feed to FR team to enable them to proactively resolve any potential issues.</p>\r\n', 'INR 120,000 - 150,000 ', 'Angel Finance', 'www.angel.com', '6656987412', 'angel@gmail.com', '10', '203, 2nd Floor, Heena Arcade,\r\n, Near Govinda Complex,Newyork', 'Candidates pass out with MBA course can also preferred.', '*To provide technical support in the field,\r\n* Installation of new ISP connections,\r\n* Maintain Networks.', '92517_finance1.jpg', '40.7127837', '-74.00594130000002', '0'),
(12, '22', 'Specialist Officers', 'Officer', '<p>Indian Bank has given employment notification for the recruitment of 251 Specialist Officer (Assistant Manager, Manager, Senior Manager &amp; Chief Manager) vacancies. Eligible candidates may apply online from 16-07-2014 to 30-07-2014. Other details li', 'INR 120,000 - 150,000 ', 'Indian Bank ', 'www.indiabank.org', '281-483-1260', 'indiabank@gmail.com', '70', '4-GUPKAR ROAD, DURGANAG, SRINAGAR 190001 \r\nState: JAMMU & KASHMIR', 'Candidates must possess B.E/ B.Tech degree in Electrical & Electronics/ Textile/ Chemical/ Mechanical Engineering/ Production Engineering degree for Posts 1 & 2, P.G qualification in Management for Post 3, P.G in Economics for Post 4, Graduation for Post ', 'Eligible candidates may apply online through the website\r\n\r\n ', '46353_bank_of_america.jpg', '34.0836581', '74.79736809999997', '0'),
(13, '22', 'Specialist Officers', 'Officer', '<p>United Bank of India has issued a notification for the recruitment of Senior Relationship Manager, Relationship Manager, Assistant officer, Messenger/ Sub staff vacancies. Eligible candidates may apply online &amp; send the printout copies of applicati', 'INR 120,000 - 150,000 ', 'United Bank of India ', 'www.lyndon.uk', '6656987412', 'angel@gmail.com', '10', '4-GUPKAR ROAD, DURGANAG, Manavadar,190001 \r\n ', 'Candidates should possess Graduation or Post graduation in Commerce/ Economics/ Management/ International Business from a recognized University for Sr Relationship Manager, Relationship Manager Post, graduation in any discipline with a minimum of 50% mark', 'Candidates will be selected based on their performance in interview.\r\n ', '78903_bank1.jpg', '21.5', '70.13', '0'),
(14, '23', 'Teacher', 'Junior ', '<p>This position offers a really fantastic opportunity for a teacher to enhance the prospects of some troubled students. The ideal candidate must be highly competent in teaching KS3 and 4 and be confident in their approach. The successful candidate will h', '$78,355.00 to $101,859.00 / Per Year', 'Oxford School', 'www.oxford.com', '281-483-1260', 'oxford@gmail.com', '5', 'Dalva,Manavadar-362630', 'Any Graduate', '* You must have the legal right to work in the UK \r\n* You must hold QTS or a UK recognised equivalent teaching qualification \r\n* This position is subject to an Enhanced CRB Disclosure, Overseas Police Clearances (if applicable) and professional reference ', '63201_education1.jpg', '21.499600707549813', '70.13051498413097', '0');

--
-- Dumping data for table `tbl_settings`
--

INSERT INTO `tbl_settings` (`id`, `app_name`, `app_logo`, `app_email`, `app_website`, `app_description`) VALUES
(2, 'News Application', 'viavi_logo.png', 'info@viaviweb.com', 'http://viaviweb.in', '<p>The content provided in this app is demo are for demonstrative purposes only and are not available for use by buyers.i not owner of that all &nbsp;information we are found on Internet by google</p>\n');