<?php include("includes/db_connection.php");
 
	
	if(isset($_GET['category_id']))
	{
		
		$cat_id=$_GET['category_id'];		
	
			$query="SELECT * FROM tbl_job
		LEFT JOIN tbl_category ON tbl_job.category_id= tbl_category.cid 
		where tbl_job.category_id='".$cat_id."'";
		
	}
	else if(isset($_GET['latest']))
	{
		$limit=$_GET['latest'];	 	
		$query="SELECT * FROM tbl_job
		LEFT JOIN tbl_category ON tbl_job.category_id= tbl_category.cid 
		ORDER BY tbl_job.id DESC LIMIT $limit";
	}
	else
	{
		$query="SELECT cid,category_name,category_image FROM tbl_category";
			
	}
	
	
     
	$resouter = mysql_query($query);
     
    $set = array();
     
    $total_records = mysql_numrows($resouter);
    if($total_records >= 1){
     
      while ($link = mysql_fetch_array($resouter, MYSQL_ASSOC)){
	   
        $set['JobApps'][] = $link;
      }
    }
     
     echo $val= str_replace('\\/', '/', json_encode($set));
	 	 
	 
?>