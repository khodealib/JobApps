﻿<div class="sidebar-nav">
        <a href="dashboard" class="nav-header"><i class="icon-dashboard"></i>داشبورد<i class="icon-chevron-up"></i></a>
        
 		
         <a href="categories" class="nav-header"><i class="icon-pencil"></i>دسته بندی<i class="icon-chevron-up"></i></a>
         
                 
        <a href="manage_job" class="nav-header"><i class="icon-book"></i>لیست کار<i class="icon-chevron-up"></i></a>
        
        
         </div>
                
    </div>