﻿<footer>
                        <hr>

                        <!-- Purchase a site license to remove this link from the footer: http://www.portnine.com/bootstrap-themes -->
                        <p class="pull-right">A <a href="http://www.viaviweb.com" target="_blank">Design & php Developed</a> by <a href="http://www.viaviweb.com" target="_blank">devhelp.ir</a></p>

                        <p>&copy; 2014 <a href="#" target="_blank">کد نویسان جوان</a></p>
                    </footer>
                    
            </div>
        </div>
    </div>
    
<script src="lib/bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript">
        $("[rel=tooltip]").tooltip();
        $(function() {
            $('.demo-cancel-click').click(function(){return false;});
        });
    </script>
    
  </body>
</html>